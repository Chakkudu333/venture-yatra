import React from 'react';
import logoImg from '../assets/img/footerLogo.png'

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 footer">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Logo and Description */}
          <div className="mb-6 md:mb-0">
            <div className="flex items-center mb-4">
              <div className=" p-2 rounded mr-3">
            <img src={logoImg} alt="" />
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="mb-6 md:mb-0">
            <h3 className="text-xl font-semibold mb-6">Quick Link</h3>
            <ul className="space-y-4">
              {['About Us', 'Mentors', 'Projects', 'Partners'].map((link) => (
                <li key={link} className="flex items-center">
                  <span className="text-blue-500 mr-2 text-2xl">•</span>
                  <a href="#" className="hover:text-blue-400 transition text-2xl">{link}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className=" font-semibold mb-6 text-2xl">Contact Us</h3>
            <p className="mb-4 w-2/4 text-2xl">Lorem ipsum is text commonly used in the graphic,</p>
            <div className="mt-6">
              <p className="mb-2 text-2xl">Have you any Quires?</p>
              <p className="mb-1 text-2xl">+91 12233333333</p>
              <p className="mb-1 text-2xl">+91 21223333333</p>
            </div>
          </div>
        </div>

        {/* Copyright Section */}
       
      </div>
      <div>
      <div className="border-t border-gray-800 mt-12 pt-8 bg-white pb-4">
        <div className='container mx-auto px-6'>
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-400 mb-4 md:mb-0">Copyright © {new Date().getFullYear()}</p>
            <div className="text-sm text-gray-400">
              All Rights Reserved | 
              <a href="#" className="text-blue-400 hover:underline ml-1">Terms and Conditions</a> | 
              <a href="#" className="text-blue-400 hover:underline ml-1">Privacy Policy</a>
            </div>
          </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;