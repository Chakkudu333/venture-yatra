import ImgOne from "../assets/img/1.png"
import ImgTwo from "../assets/img/2.png"
import ImgThree from "../assets/img/3.png"
import ImgFour from "../assets/img/4.png"



const StatsGrid = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4  bg-[#191919] text-white">
      <div className="relative border-[0.1px] border-[#3a3a3a]">
        <img src={ImgOne} alt="Teamwork" className="w-full h-full object-cover opacity-80" />
      </div>

      {/* Stat 1 */}
      <div className="flex flex-col justify-center items-center p-6 bg-gray-900 text-center border-[0.1px] border-[#3a3a3a]">
        <div className="flex flex-col md:gap-22 gap-12">
          <p className="text-white text-left text-xl ">2025</p>
          <div className="text-left">
            <h2 className="text-5xl mb-3">20%</h2>
            <p className="text-2xl">The growth of entrepreneurs nationwide.</p>
          </div>
        </div>
      </div>

      {/* Image 2 */}
      <div className="relative border-[0.1px] border-[#3a3a3a]">
        <img src={ImgTwo} alt="Night Meeting" className="w-full h-full object-cover opacity-80" />
      </div>

      {/* Stat 2 */}
      <div className="flex flex-col justify-center items-center p-6 bg-gray-900 text-centerborder-[0.1px] border-[#3a3a3a]">
        <div className="flex flex-col md:gap-22 gap-12">
          <p className="text-white text-left text-xl ">New</p>
          <div className="text-left">
            <h2 className="text-5xl mb-3">100%</h2>
            <p className="text-2xl">To be India's foremost startup community</p>
          </div>
        </div>
      </div>

       <div className="flex flex-col justify-center items-center p-6 bg-gray-900 text-center border-[0.1px] border-[#3a3a3a]">
        <div className="flex flex-col md:gap-22 gap-12">
          <p className="text-white text-left text-xl ">New</p>
          <div className="text-left">
            <h2 className="text-5xl mb-3">100+</h2>
            <p className="text-2xl">The growth of entrepreneurs nationwide.</p>
          </div>
        </div>
      </div>
      <div className="relative border-[0.1px] border-[#3a3a3a]">
        <img src={ImgThree} alt="Night Meeting" className="w-full h-full object-cover opacity-80" />
      </div>

       <div className="flex flex-col justify-center items-center p-6 bg-gray-900 text-center border-[0.1px] border-[#3a3a3a]">
        <div className="flex flex-col md:gap-22 gap-12">
          <p className="text-white text-left text-xl ">Creative</p>
          <div className="text-left">
            <h2 className="text-5xl mb-3"></h2>
            <p className="text-2xl">The growth of entrepreneurs nationwide.</p>
          </div>
        </div>
      </div>
      <div className="relative border-[0.1px] border-[#3a3a3a]">
        <img src={ImgFour} alt="Night Meeting" className="w-full h-full object-cover opacity-80" />
      </div>

   
    </div>
  );
};

export default StatsGrid;
