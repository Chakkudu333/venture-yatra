import React from 'react'

export const AccordionItem = ({ question, isOpen, onClick }) => {
  return (
    <div>
        


        <div className="border-b border-[#545454]">
      <button
        className="w-full py-5 px-4 text-left flex justify-between items-center focus:outline-none"
        onClick={onClick}
      >
        <span className="text-lg font-medium text-gray-900">{question}</span>
        <span className="ml-6 border-1 text-[#0414cd]  rounded-2xl  ">
          <svg
            className={`w-5 h-5 text-[#0414cd] transform ${isOpen ? 'rotate-180' : ''} p-1`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d={isOpen ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"}
            />
          </svg>
        </span>
      </button>
      {isOpen && (
        <div className="pb-5 px-4">
          <p className="text-gray-600">
            This is the answer to the question. You can replace this with your actual answer content.
          </p>
        </div>
      )}
    </div>
    </div>
  )
}
