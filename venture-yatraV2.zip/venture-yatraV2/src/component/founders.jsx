import imgOne from "../assets/img/FounderOne.png";
import imgTwo from "../assets/img/FounderTwo.png";
import imgThree from "../assets/img/FounderThree.png";

const Founder = () => {
  const founders = [
    {
      name: "John Simon",
      role: "Co-founder",
      image: imgOne,
      backgroundColor: "bg-gray-100"
    },
    {
      name: "Walt Kiza",
      role: "Co-founder",
      image: imgTwo,
      backgroundColor: "bg-gray-300",
      labelColor: "bg-blue-500 text-white"
    },
    {
      name: "Selena Gomez",
      role: "Co-founder",
      image: imgThree,
      backgroundColor: "bg-gray-200"
    }
  ];
  
  return (
    <section className="pl-0 md:pl-20 bg-[#F2F2F2] py-10 md:py-22">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {founders.map((founder, index) => (
            <div key={index} className={`relative ${founder.backgroundColor} overflow-hidden`}>
              <img
                src={founder.image}
                alt={`${founder.name} - ${founder.role}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-8 left-8">
                <div className={`p-6 ${founder.labelColor || 'bg-white'}`}>
                  <h3 className="text-xl font-bold">{founder.name}</h3>
                  <p className="text-lg">{founder.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Founder;