import React from 'react';

const ScrollingLogoAnimationTwo = () => {
  // Create an array with logo elements to repeat
  const logoElements = Array(12).fill(null);

  return (
    <div className="relative w-full h-24 bg-black overflow-hidden py-6">
      {/* First loop */}
      <div
        className="absolute flex whitespace-nowrap"
        style={{
          animation: 'marquee-rtl 120s linear infinite',
          animationDelay: '0s',
        }}
      >
        {logoElements.map((_, index) => (
          <div key={`first-${index}`} className="flex items-center">
            <span className="text-white text-4xl font-bold px-4">Logo</span>
            <span className="text-white text-4xl">★</span>
          </div>
        ))}
      </div>

      {/* Duplicate for seamless looping */}
      <div
        className="absolute flex whitespace-nowrap"
        style={{
          animation: 'marquee-rtl 120s linear infinite',
          animationDelay: '-60s', // Start halfway through to create perfect loop
        }}
      >
        {logoElements.map((_, index) => (
          <div key={`second-${index}`} className="flex items-center">
            <span className="text-white text-4xl font-bold px-4">Logo</span>
            <span className="text-white text-4xl">★</span>
          </div>
        ))}
      </div>

      {/* Add keyframes for animation */}
      <style jsx>{`
        @keyframes marquee-rtl {
          0% {
            transform: translateX(100%);
          }
          100% {
            transform: translateX(-100%);
          }
        }
      `}</style>
    </div>
  );
};

export default ScrollingLogoAnimation;