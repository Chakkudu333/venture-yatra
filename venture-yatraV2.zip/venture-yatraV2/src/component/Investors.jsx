import React, { useState } from 'react';
import LeadersImg from '../assets/img/founder.png'
import icon from '../assets/icon/icon.png'


const CommunityLeadersSection = () => {
  // State to track the current image index
  const [currentImage, setCurrentImage] = useState(1);
  
  // Sample images data (using placeholders)
  const images = [
    { id: 0, src: LeadersImg, alt: "Leader 1", name: "Ethan Williams", position: "Startup Mentor", quote: "Great leaders don't set out to be leaders, they set out to make a difference." },
    { id: 1, src: LeadersImg, alt: "Leader 2", name: "Sophia Carter", position: "Tech Innovator", quote: "Leadership is not about power; it’s about empowering others to succeed. True leaders create opportunities and inspire progress." },
    { id: 2, src: LeadersImg, alt: "Leader 3", name: "Liam Johnson", position: "Industry Expert", quote: "Success in leadership is not measured by what you accomplish, but by what you inspire others to do." }
  ];
  
  // Function to handle dot click
  const handleDotClick = (index) => {
    setCurrentImage(index);
  };
  
  return (
    <div className="flex flex-col md:flex-row w-full overflow-hidden">
      {/* Left side - Image */}
      <div className="w-full md:w-1/2 bg-black relative">
        <img 
        
          src={images[currentImage].src} 
          alt={images[currentImage].alt} 
          className="w-full h-full object-cover grayscale"
        />
        
        {/* Navigation dots */}
        <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-2">
          {images.map((image, index) => (
            <button 
              key={image.id}
              onClick={() => handleDotClick(index)}
              className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                currentImage === index ? 'bg-blue-500' : 'bg-gray-300 hover:bg-gray-400'
              }`}
              aria-label={`View image ${index + 1}`}
            ></button>
          ))}
        </div>
      </div>
      
      {/* Right side - Content */}
      <div className="w-full md:w-1/2 flex flex-col">
        {/* Top white section */}
        <div className="bg-white p-8 md:p-12">
          <div className="md:mb-8 mb-2 ">
            <h3 className="thin-text">Investors</h3>
            <h2 className="blod-text">Community Leaders</h2>
          </div>
          
          <div className="mt-4">
            <p className="text-gray-800 text-xl leading-relaxed">
            Industry experts, seasoned  entrepreneurs, and investors can apply to become mentors or investors through our platform. Our  team will assess applications to ensure alignment with our community goals.
            </p>
          </div>
        </div>
        
        {/* Bottom gray section with quote */}
        <div className="bg-gray-100 px-8 md:px-12 pt-3 flex-grow flex items-center">
          <div className="bg-gray-900 text-white p-6 md:p-8 relative">
            {/* Quote marks */}
           
        <div className=' absolute md:top-[-80px] top-[-20px] right-0'>
            <img src={icon} alt=""  className='w-20 md:w-full'/>
        </div>
            
            <div className="mb-6">
              <h4 className="text-xl md:text-2xl font-bold">{images[currentImage].name}</h4>
              <p className="text-gray-300">{images[currentImage].position}</p>
            </div>
            
            <blockquote className="relative z-10">
              <p className="text-lg md:text-xl italic leading-relaxed">
                "{images[currentImage].quote}"
              </p>
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommunityLeadersSection;
