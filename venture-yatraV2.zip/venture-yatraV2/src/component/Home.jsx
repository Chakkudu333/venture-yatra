import React from 'react';
// import './component.css';
import scroll from '../assets/img/scroll.png';
import BackGroundOne from '../assets/img/bg-1.png';

export const Home = () => {
  return (
    <div>
      <div>
        <div className="min-h-screen relative">
          <div className="relative h-[70vh] md:h-[95vh] home-bg">
            <div className="container mx-auto px-4 py-16 relative z-10 flex items-center w-full h-full">
              <div className="ml-0 md:ml-40">
                <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white mt-0 md:mt-22">Empowering Your Journey</h2>
                <h3 className="text-2xl md:text-3xl text-gray-300 mb-8">Smart Investments, Brighter Futures.</h3>
                <div>
                  <button className="bg-[#007AFF] text-white font-bold py-2 px-4 md:py-6 md:px-10 text-xl hover:bg-[#007bff]">
                    Join our community
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="container shape-bg absolute bottom-[33px] right-0 hidden md:block">
            <div className="items-center h-full flex">
              <div className="flex flex-col items-center text-left">
                <p className="text-white text-xl w-[75%] text-left pl-0 md:pl-10 mb-3">We host a variety of networking events, investor pitch sessions,</p>
                <img src={scroll} alt="" width="8px" />
              </div>
            </div>
          </div>
          <div className="bg-white text-black pt-8 pb-10 ">
            <div className="container mx-auto px-11">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/3 mb-8 md:mb-0">
                  <p className="thin-text">About us</p>
                  <h3 className="blod-text">Who We Are</h3>
                </div>
                <div className="md:w-2/3">
                  <p className="thin-p md:w-[70%] w-[100%]">
                    Welcome to VentureYatra, an exclusive startup community dedicated to empowering young entrepreneurs who aspire to contribute to India's economic growth.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="pl-0 md:pl-20 mt-20 md:mt-0">
        <div className="relative flex justify-center items-center">
          <img src={BackGroundOne} alt="" className="w-full h-auto object-cover" />
          <div className="absolute bg-white top-1/2 left-0 transform -translate-y-1/2 p-4 md:py-18 md:w-[25%] w-[100%] md:ml-20 ml:0 ">
            <p className=" text-lg md:text-xl text-center">Our platform serves as a catalyst for innovation, bridging the gap between groundbreaking ideas and successful execution.</p>
            <div className="flex items-center w-full justify-center">
              <button className="bg-[#007AFF] text-white font-bold py-2 px-4 md:py-6 md:px-10 text-xl hover:bg-[#007bff] mt-6">
                Read more
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-11 py-20">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/3 mb-8 md:mb-0">
            <p className="thin-text">Services</p>
            <h3 className="blod-text">Why Join Us?</h3>
          </div>
          <div className="md:w-2/3">
            <p className="thin-p md:w-[70%] w-[100%]">
              We host a variety of networking events, investor pitch sessions, panel discussions, and skill-enhancing workshops to equip entrepreneurs with the knowledge and connections.                  </p>
          </div>
        </div>
      </div>
    </div>
  );
};