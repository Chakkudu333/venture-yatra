// tailwind.config.js
module.exports = {
    theme: {
      extend: {
        animation: {
          'marquee-rtl': 'marquee-rtl 120s linear infinite',
          'marquee2-rtl': 'marquee2-rtl 120s linear infinite',
        },
        keyframes: {
          'marquee-rtl': {
            '0%': { transform: 'translateX(0%)' },
            '100%': { transform: 'translateX(-100%)' },
          },
          'marquee2-rtl': {
            '0%': { transform: 'translateX(100%)' },
            '100%': { transform: 'translateX(0%)' },
          },
        },
      },
    },
    plugins: [],
  };